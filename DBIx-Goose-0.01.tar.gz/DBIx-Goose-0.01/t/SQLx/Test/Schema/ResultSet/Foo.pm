package SQLx::Test::Schema::ResultSet::Foo;

use base 'DBIx::Goose';

sub table { 'foo'; }

1;
