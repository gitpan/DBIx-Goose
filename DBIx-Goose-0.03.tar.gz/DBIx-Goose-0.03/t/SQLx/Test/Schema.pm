package SQLx::Test::Schema;

use base 'DBIx::Goose';

__PACKAGE__->load_namespaces;

1;
